const express = require("express");
const ejs = require("ejs");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const path = require("path");
//const passport = require("passport");
//const bcrypt = require("bcrypt");
//const session = require("express-session");

mongoose.connect("mongodb://localhost:27017/EmployeeDB");
const app = express();
const User = require("./model/schema");

app.use(express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({extended:false}));
//app.use(session({ secret: 'keyboard cat', resave: true, saveUninitialized: true }));
//app.use(passport.initialize());
//app.use(passport.session());
app.set("view engine", "ejs");

app.get("/", async(req, res) => {
    const documents = await User.find();
    res.render("index", {documents:documents});
});

app.get("/new", (req, res) => {
    res.render("newform");
});

app.get("/edit", async(req, res) => {
    var id = req.query.id;
    if(id != undefined) {
        const result = await User.findById(id);
        res.render("editform", {object:result});
    }
    else {
        res.render("editform", {object:""});
    }
});

app.get("/search", async(req, res) => {
    var filter = req.query.filter;
    var result = req.query.result
    if(filter != undefined) {
        let users;
        switch(filter) {
            case "FirstName":
                users = await User.find({FirstName: result});
                break;
            case "LastName":
                users = await User.find({LastName: result});
                break;
            case "Email":
                users = await User.find({Email: result});
                break;
            case "PhoneNumber":
                users = await User.find({PhoneNumber: result});
                break;  
        }
        res.render("index", {documents:users});
    }
    else {
        res.redirect("/");
    }
});

app.post("/new", async(req, res) => {
    //console.log(req.body);
    const data = new User(req.body);
    await data.save();
    res.redirect("/");
});

app.post("/edit", (req, res) => {
    User.findByIdAndUpdate(req.body._id, req.body, (err) => {
            if(err) throw err;
        });
    res.redirect("/");
});

app.post("/", (req, res) => {
    const objName = Object.keys(req.body).toString();
    if(objName == "edit") {
        res.redirect(`/edit/?id=${req.body.edit}`);
    }
    else if(objName == "delete") {
        User.findByIdAndDelete(req.body.delete, (err, docs) => {
            if(err) throw err;
        });
        res.redirect("/");
    }
    else {
        res.redirect("/");
    }
});

app.listen(5000, () => {
    console.log("Server started at port 5000");
});