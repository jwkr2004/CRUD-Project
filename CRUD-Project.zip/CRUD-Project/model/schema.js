const mongoose = require("mongoose");
const userSchema = new mongoose.Schema({
    FirstName:{
        type:String
    },
    LastName:{
        type:String
    },
    PhoneNumber:{
        type:Number
    },
    Email:{
        type:String
    },
    Notes:{
        type:String
    },
    UserName:{
        type:String
    },
    Password:{
        type:String
    }
});
const User = mongoose.model("User", userSchema);
module.exports = User;
